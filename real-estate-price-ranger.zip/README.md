**Notice of Non-Affiliation and Disclaimer**

realestate.com.au is owned and operated by ASX-listed REA Group Ltd (REA:ASX) © REA Group Ltd.

We are not affiliated, associated, authorized, endorsed by, or in any way officially connected with the REA Group Ltd,
or any of its subsidiaries or its affiliates.
